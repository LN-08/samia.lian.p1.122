package samiap1;

public class Postre extends Plato implements Decorable {

    private boolean tieneAzucar;

    public Postre(String nombre, int precio, TipoPreparacion tipoPreparacion, boolean tieneAzucar) {
        super(nombre, precio, tipoPreparacion);
        this.tieneAzucar = tieneAzucar;
    }

    public boolean postreTieneAzucar() {
        return tieneAzucar;
    }
    
    @Override
    public String getTipoPlato() {
        return "Postre";
    }
    
    @Override
    public void decorar() {
        if (tieneAzucar) {
            System.out.println("Postre decorado: '" + getNombre() + "'. Tiene Azucar?: Si");
        } else {
            System.out.println("Postre decorado: '" + getNombre() + "' . Tiene Azucar?: No");
        }
    }

    @Override
    public String toString() {
        String tieneAzucarStr;
        if (tieneAzucar) {
            tieneAzucarStr = "Si";
        } else {
            tieneAzucarStr = "No";
        }
        
        return "Postre: " + super.toString() + " - Contiene azucar: " + tieneAzucarStr;
    }
}
