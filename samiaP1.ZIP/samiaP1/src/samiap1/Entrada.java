package samiap1;

public class Entrada extends Plato implements Preparable, Decorable {

    private int cantIngredientes;

    public Entrada(String nombre, int precio, TipoPreparacion tipoPreparacion, int cantIngredientes) {
        super(nombre, precio, tipoPreparacion);
        this.cantIngredientes = cantIngredientes;
    }

    public int getCantIngredientes() {
        return cantIngredientes;
    }
    
    @Override
    public String getTipoPlato() {
        return "Entrada";
    }

    @Override
    public void preparar() {
        System.out.println("Plato preparado: '" + getNombre() + "'. Cant Ingredientes: " + cantIngredientes);
    }

    @Override
    public void decorar() {
        System.out.println("Entrada decorada: '" + getNombre() + "'.");
    }

    @Override
    public String toString() {
        return "Entrada: " + super.toString() + " - Cant Ingredientes: " + cantIngredientes;
    }
}
