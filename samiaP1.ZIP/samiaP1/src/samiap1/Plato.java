package samiap1;

public abstract class Plato {

    private String nombre;
    private int precio;
    private TipoPreparacion tipoPreparacion;

    public Plato(String nombre, int precio, TipoPreparacion tipoPreparacion) {
        this.nombre = nombre;
        this.precio = precio;
        this.tipoPreparacion = tipoPreparacion;
    }

    public String getNombre() {
        return nombre;
    }

    public int getPrecio() {
        return precio;
    }

    public TipoPreparacion getTipoPreparacion() {
        return tipoPreparacion;
    }
    
    public abstract String getTipoPlato();
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || !(obj instanceof Plato)) {
            return false;
        }
        Plato p = (Plato) obj;
        return this.nombre.equals(p.nombre) && this.tipoPreparacion == p.tipoPreparacion;
    }
    
    @Override 
    public int hashCode() { 
        return java.util.Objects.hash(nombre, tipoPreparacion);
    }
    
    @Override
    public String toString() {
        return "Nombre: " + nombre + " - Precio: $" + precio + " - Tipo preparacion: " + tipoPreparacion;
    }
}
