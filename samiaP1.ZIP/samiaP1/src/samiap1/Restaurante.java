package samiap1;

import java.util.ArrayList;

public class Restaurante {

    private ArrayList<Plato> listaPlatos;

    public Restaurante() {
        listaPlatos = new ArrayList<>();
    }

    public void agregarPlato(Plato plato) throws PlatoDuplicadoException {
        boolean repetido = false;

        for (int i = 0; i < listaPlatos.size(); i++) {
            Plato platoActual = listaPlatos.get(i);
            if (platoActual.equals(plato)) {
                repetido = true;
            }
        }

        if (repetido) {
            throw new PlatoDuplicadoException("Plato repetido.");
        } else {
            listaPlatos.add(plato);
            System.out.println("Plato agregado: " + plato.getNombre());
        }
    }

    public void mostrarPlatos() {
        if (listaPlatos.isEmpty()) {
            System.out.println("No hay platos en la lista.");
        } else {
            for (int i = 0; i < listaPlatos.size(); i++) {
                Plato p = listaPlatos.get(i);
                System.out.println(p.toString());
            }
        }
    }

    public void prepararPlato(Plato plato) {
        if (plato instanceof Preparable) {
            Preparable p = (Preparable) plato;
            p.preparar();
        } else {
            System.out.println("el plato" + plato.getNombre() + " no se puede preparar.");
        }
    }

    public void decorarPlato(Plato plato) {
        if (plato instanceof Decorable) {
            Decorable d = (Decorable) plato;
            d.decorar();
        } else {
            System.out.println("El plato " + plato.getNombre() + " no se puede decorar.");
        }
    }

    public ArrayList<Plato> filtrarPorTipoPreparacion(TipoPreparacion tipo) {
        ArrayList<Plato> platosFiltrados = new ArrayList<>();
        for (int i = 0; i < listaPlatos.size(); i++) {
            Plato p = listaPlatos.get(i);
            if (p.getTipoPreparacion() == tipo) {
                platosFiltrados.add(p);
            }
        }
        return platosFiltrados;
    }

    public ArrayList<Plato> mostrarPlatosPorTipo(String tipoPlato) {
        ArrayList<Plato> platosFiltrados = new ArrayList<>();

        for (int i = 0; i < listaPlatos.size(); i++) {
            Plato p = listaPlatos.get(i);
            if (p.getTipoPlato().equals(tipoPlato)) {
                platosFiltrados.add(p);
            }
        }

        return platosFiltrados;
    }

    
    
}
