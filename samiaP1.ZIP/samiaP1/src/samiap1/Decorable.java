package samiap1;

public interface Decorable {
    void decorar();
}
