package samiap1;

public enum TipoPreparacion {
    FRIA,
    CALIENTE
}
