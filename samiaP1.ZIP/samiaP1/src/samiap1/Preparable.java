package samiap1;

public interface Preparable {
    void preparar();
}
