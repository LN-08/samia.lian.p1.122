package samiap1;

public class SamiaP1 {
 
    public static void main(String[] args) {
        try {
            Restaurante restaurante = new Restaurante();

            Entrada e1 = new Entrada("Bruschetta", 2000, TipoPreparacion.FRIA, 5);
            Entrada e2 = new Entrada("Bruschetta", 2000, TipoPreparacion.FRIA, 5);
            Entrada e3 = new Entrada("entrada", 2000, TipoPreparacion.CALIENTE, 5);
            PlatoPrincipal p1 = new PlatoPrincipal("Ravioles", 3000, TipoPreparacion.CALIENTE, 15);
            Postre po1 = new Postre("Tiramisu", 1000, TipoPreparacion.FRIA, true);

            restaurante.agregarPlato(e1);
            //restaurante.agregarPlato(e2);
            restaurante.agregarPlato(e3);
            restaurante.agregarPlato(p1);
            restaurante.agregarPlato(po1);

            System.out.println("Todos los platos:");
            restaurante.mostrarPlatos();

            System.out.println("Preparaciones: ");
            restaurante.prepararPlato(e1);
            restaurante.prepararPlato(p1);
            restaurante.prepararPlato(po1);

            System.out.println("Decoraciones:");
            restaurante.decorarPlato(e1);
            restaurante.decorarPlato(p1);
            restaurante.decorarPlato(po1);

            System.out.println("Platos de preparacion fria:");
            for (Plato p : restaurante.filtrarPorTipoPreparacion(TipoPreparacion.FRIA)) {
                System.out.println(p);
            }

            System.out.println("Postres:");
            for (Plato p : restaurante.mostrarPlatosPorTipo("Postre")) {
                System.out.println(p);
            }
        } catch (PlatoDuplicadoException e) {
            throw new RuntimeException("Plato duplucado");
        }
    }
      
}

