package samiap1;

public class PlatoPrincipal extends Plato implements Preparable {

    private int tiempoCoccion;

    public PlatoPrincipal(String nombre, int precio, TipoPreparacion tipoPreparacion, int tiempoCoccion) {
        super(nombre, precio, tipoPreparacion);
        this.tiempoCoccion = tiempoCoccion;
    }

    public int getTiempoCoccion() {
        return tiempoCoccion;
    }
    
    @Override
    public String getTipoPlato() {
        return "PlatoPrincipal";
    }

    @Override
    public void preparar() {
        System.out.println("Plato preparado: '" + getNombre() + "'. Tiempo de coccion: " + tiempoCoccion + " minutos.");
    }

    @Override
    public String toString() {
        return "Plato Principal: " + super.toString() + " - Tiempo coccion: " + tiempoCoccion;
    }
}
