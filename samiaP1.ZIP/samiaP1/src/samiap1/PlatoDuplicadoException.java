package samiap1;

public class PlatoDuplicadoException extends Exception {

    public PlatoDuplicadoException() {
        super("Plato duplicado.");
    }

    public PlatoDuplicadoException(String mensaje) {
        super(mensaje);
    }
}
